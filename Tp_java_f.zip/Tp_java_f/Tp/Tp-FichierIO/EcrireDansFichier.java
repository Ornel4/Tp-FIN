// Code généré pour Tp-FichierIO
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Cette classe permet de créer un fichier et d'y écrire plusieurs lignes de texte.
 */
public class FichierEcriture {
    public static void main(String[] args) {
        File fichier = new File("donnees.txt");

        // Vérification si le fichier existe déjà
        if (!fichier.exists()) {
            try {
                fichier.createNewFile();
            } catch (IOException erreur) {
                System.err.println("Erreur lors de la création du fichier : " + erreur.getMessage());
            }
        }

        // Écriture dans le fichier
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier))) {
            writer.write("Ceci est une démonstration de l'écriture dans un fichier texte.");
            writer.newLine();
            writer.write("Chaque ligne est ajoutée à l'aide de BufferedWriter.");
            writer.newLine();
            writer.write("Ce TP montre comment créer et écrire dans un fichier en Java.");
            writer.newLine();
            writer.write("Bonne lecture !");
        } catch (IOException erreur) {
            System.err.println("Erreur lors de l'écriture dans le fichier : " + erreur.getMessage());
        }
    }
}
