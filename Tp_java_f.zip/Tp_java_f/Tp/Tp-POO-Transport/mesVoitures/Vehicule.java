// Code généré pour mesVoitures
package mesVoitures;

public interface Vehicule {
    public void demarrer();
    public void arreter();
    public int getVitesseMax();
}
